"""Extended functionalities module"""
